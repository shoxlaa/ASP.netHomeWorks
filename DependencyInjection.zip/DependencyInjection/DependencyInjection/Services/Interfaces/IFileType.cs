﻿namespace DependencyInjection.Services.Interfaces;

public interface IFileType
{
    void Create(string value);
}
