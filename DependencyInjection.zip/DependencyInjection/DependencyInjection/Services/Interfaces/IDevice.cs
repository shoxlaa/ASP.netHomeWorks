﻿namespace DependencyInjection.Services.Interfaces;
public interface IDevice
    {

        string Show(IShow show);
    }




